

class TVDB {
    
    __mirrorpath = "http://thetvdb.com"
    __language = "en"
    
    def __init__(self, apiKey):
        self.apiKey = apiKey
    
    
}